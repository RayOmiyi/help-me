# HelpMeOut

### [API URL](https://seashell-app-4jicj.ondigitalocean.app/)

### [Client URL](https://helpmeoutapp.vercel.app/)

### Some Links on client side

- View all uploaded videos

  - [https://helpmeoutapp.vercel.app/home](https://helpmeoutapp.vercel.app/home)

- View a specific video
  - [https://helpmeoutapp.vercel.app/file/videoId](https://helpmeoutapp.vercel.app/video/videoId)
    > If the video dont exists, a 404 video animation would be played.

## Extension

To use the extension, download it from the link below:
[Extension release link]()
