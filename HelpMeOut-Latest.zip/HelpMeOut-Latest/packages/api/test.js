const { transcribeAudio } = require("./helper/video");

// 0923
(async () => {
  await transcribeAudio("./storage/videos/NcSPCHRN5b.webm", "sdcsdsdc");
})();
